package com.sapient.exceptions;

public class AgeException extends Exception{

	public AgeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
