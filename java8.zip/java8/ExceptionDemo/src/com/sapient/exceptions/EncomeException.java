package com.sapient.exceptions;

public class EncomeException extends Exception{

	public EncomeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
