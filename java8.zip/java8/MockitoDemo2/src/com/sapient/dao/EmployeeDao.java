package com.sapient.dao;

import java.util.List;

import com.sapient.vo.Employee;

public interface EmployeeDao {
	List<Employee> getEmployee();
}
