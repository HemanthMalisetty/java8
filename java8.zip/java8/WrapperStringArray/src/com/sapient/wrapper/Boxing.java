package com.sapient.wrapper;

public class Boxing {
		
		
		public static void main(String args[]) {
			Integer a=new Integer(10);
			
			int res=a.intValue();//unboxing
			System.out.println(a);
		}
}
