package com.sapient.wrapper;

public class Conversion {

	public static void main(String[] args) {
		int dec=44;
		System.out.println("Binary of 44:  "+ Integer.toBinaryString(dec));
		System.out.println("Octal of 44:  "+ Integer.toOctalString(dec));
		System.out.println("hexadeciaml of 44:  "+ Integer.toHexString(dec));
		

	}

}
