package com.sapient.service;

import java.math.BigInteger;

public interface Factorial {
	BigInteger findFactorial(int num);
	int doSum(int ...a);
}
