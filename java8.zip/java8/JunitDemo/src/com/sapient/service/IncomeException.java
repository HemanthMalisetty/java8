package com.sapient.service;

public class IncomeException extends Exception{

	public IncomeException(String message) {
		super(message);
		
		
	}
	
}
