package com.sapient.services;

import java.util.List;

public interface IDao {
	int num=0;  //it will make static final variable
	List<String> viewEmployee();
}
