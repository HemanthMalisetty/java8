package com.sapient.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import static com.sapient.util.Factory.*;

import com.sapient.entity.Product;

public class ProductDaoImpl implements ProductDao {

static {
		
		try {
			Class.forName(DRIVER);
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
	}
	
	@Override
	public int addProduct(Product product)  {
		String sql="insert into Product values(?,?,?,?,?)";
		int result=0;
		try(Connection conn=DriverManager.getConnection(URL,USERNAME,PASSWORD)){
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, product.getPid());
			pst.setString(2, product.getPname());
			pst.setDouble(3, product.getPrice());
			pst.setString(4, product.getBrand());
			pst.setInt(5, product.getCid());
			result=pst.executeUpdate();
				
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return result;
	}

	@Override
	public int deleteProduct(int pid)  {
		int result=0;
		return result;
	}

	@Override
	public boolean updateProduct(Product product) throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Product getProduct(int pid) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> getAllProducts() throws SQLException {
		String sql="insert into Product values(?,?,?,?,?)";
		List<Product> result=new ArrayList<Product>();
		Product product=new Product();
		try(Connection conn=DriverManager.getConnection(URL,USERNAME,PASSWORD)){
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, product.getPid());
			pst.setString(2, product.getPname());
			pst.setDouble(3, product.getPrice());
			pst.setString(4, product.getBrand());
			pst.setInt(5, product.getCid());
//			result=pst.executeUpdate();
				
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return result;
		
	}

}
