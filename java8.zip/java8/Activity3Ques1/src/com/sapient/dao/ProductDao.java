package com.sapient.dao;

import java.sql.SQLException;
import java.util.List;

import com.sapient.entity.Product;

public interface ProductDao {

	public int addProduct(Product product) ;
	public int deleteProduct(int pid) ;
	public boolean updateProduct(Product product) throws SQLException;
	public Product getProduct(int pid) throws SQLException;
	public List<Product> getAllProducts() throws SQLException;
	
}
