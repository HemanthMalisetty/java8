package com.sapient.client;

import java.util.Scanner;

import com.sapient.dao.ProductDao;
import com.sapient.dao.ProductDaoImpl;
import com.sapient.entity.Product;

public class ClientA {

	public static void main(String[] args) {
		ProductDao dao=new ProductDaoImpl();
		Scanner scan=new Scanner(System.in);
		Product p=new Product();
		System.out.println("Enter product details: ");
		p.setPid(scan.nextInt());
		p.setPname(scan.next());
		p.setPrice(scan.nextDouble());
		p.setBrand(scan.next());
		p.setCid(scan.nextInt());
		System.out.println(dao.addProduct(p));

	}

}
