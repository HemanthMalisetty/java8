package com.sapient.service;

public class EmpNotFoundException extends Exception{

}
