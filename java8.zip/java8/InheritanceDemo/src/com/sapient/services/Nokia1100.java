package com.sapient.services;

public class Nokia1100 {
	public void doConversation(){
		System.out.println("Do Conversation");
		
	}
	
	public void sendSms() {
		System.out.println("send SMS");
	}
}
