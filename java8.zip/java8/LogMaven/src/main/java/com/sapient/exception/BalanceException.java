package com.sapient.exception;

public class BalanceException extends Exception{

}
