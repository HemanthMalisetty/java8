package com.sapient.exception;

public class IdExceptin extends Exception{

	public IdExceptin(String message) {
		super(message);
		
	}
	
}
