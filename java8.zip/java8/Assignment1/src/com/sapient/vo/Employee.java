package com.sapient.vo;

import java.time.LocalDate;

public class Employee implements Comparable<Employee>{
	private int empId;
	private String empName;
	private double salary;
	private int deptId;
	private LocalDate date;
	private String img;
	private String pwd;
	
	
	public Employee(){
		
	}
	public Employee(int empId, String empName, double salary, int deptId, LocalDate date ) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.salary = salary;
		this.deptId = deptId;
		this.date = date;
	}
	
	
	
	public Employee(int empId, String empName, double salary, int deptId, LocalDate date, String pwd,String img) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.salary = salary;
		this.deptId = deptId;
		this.date = date;
		this.img = img;
		this.pwd = pwd;
	}
	
	
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public int getEmpId() {
		return empId;
	}
	public String getEmpName() {
		return empName;
	}
	public int getDeptId() {
		return deptId;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	
	
	
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", salary=" + salary + ", deptId=" + deptId
				+ ", date=" + date + ", img=" + img + ", pwd=" + pwd + "]";
	}
	@Override
	public int compareTo(Employee emp) {
		Integer e1=this.empId;
		Integer e2=emp.empId;
		return e1.compareTo(e2);
	}
	
	
}
