package com.sapient.client;

public enum Menu {
	ADD,VIEW,VIEWALL,UPDATE,REMOVE,DEPTS_INFO,EMP_BY_DEPTID
}
