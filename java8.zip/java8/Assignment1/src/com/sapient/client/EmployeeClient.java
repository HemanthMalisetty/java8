package com.sapient.client;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import javax.print.attribute.standard.DateTimeAtCompleted;

import com.sapient.dao.DaoFactory;
import com.sapient.dao.IDao;
import com.sapient.exception.IdException;
import com.sapient.exception.NotFoundException;
import com.sapient.vo.Department;
import com.sapient.vo.Employee;
import java.sql.SQLIntegrityConstraintViolationException;

public class EmployeeClient {

	static Scanner scanner =new  Scanner(System.in);
	static IDao dao=DaoFactory.getDaoInstance();
	public static void main(String[] args) {
		String menu=null;
		String option=null;
		Menu emenu=null;
		
		do{
		
			System.out.println("Choose: \nADD\nVIEW\nVIEWALL\nUPDATE\nREMOVE\nDEPTS_INFO\nEMP_BY_DEPTID");
			menu=scanner.next();
			try {
				emenu=Menu.valueOf(menu);
				processMenu(emenu);
			} catch (Exception e) {
				System.out.println("Invalid Menu Option");
			}
			System.out.println("Press y to continue...");
			option = scanner.next();
		}while(option.equalsIgnoreCase("y") );
		

	}
	
	public static void processMenu(Menu menu) throws NotFoundException{
		switch(menu){
		case ADD:
			add();
			break;
		case VIEW:
			viewById();
			break;
		case VIEWALL:
			viewAll();
			break;
			
		
		
		case UPDATE:
			updateEmployeeSalary();
			break;
		case REMOVE:
			remove();
			break;
		case DEPTS_INFO:
			viewAllDepartments();
			break;
		case EMP_BY_DEPTID:
			viewEmployeeByDepartmentId();
			break;
		}
		
	}
	
	public static void remove(){
		System.out.println("Enter employee id");
		int result=0;
		int eid=scanner.nextInt();
		try {
			result=dao.removeEmployee(eid);
		} catch (NotFoundException e) {
			System.out.println(e.getMessage());
		}
		if(result>0)
			System.out.println("Employee removed from database");
		else
			System.out.println("Employee not found");
		
	}
	public static void updateEmployeeSalary(){
		System.out.println("Enter employee id ");
		int eid=scanner.nextInt();
		int result=0;
		System.out.println("salary");
		double salary=scanner.nextDouble();
		try {
			result=dao.updateSalary(eid, salary);
		} catch (NotFoundException e) {
			System.out.println(e.getMessage());
		}
		if(result>0)
			System.out.println("Employee salary successfuly updated");
		else
			System.out.println("Employee not found");
			
	}
	public static void viewAllDepartments() {
		List<Department> list=dao.viewDepartments();
		for (Department department : list) {
			System.out.println(department);
		}
	}
	public static void viewEmployeeByDepartmentId() {
		System.out.println("Enter department  id");
		int deptid=scanner.nextInt();
		List<Employee> list=dao.viewByDepartmentId(deptid);
		if(list.size()>0){
			for (Employee employee : list) 
				System.out.println(employee);
		}
		else
			System.out.println("Department not found");
		
	}
	public static void viewAll() {
		List<Employee> list=dao.viewAllEmployee();
			for (Employee employee : list) {
				System.out.println(employee);
			}
	}
	
	public static void viewById(){
		System.out.println("Enter employee id");
		Employee employee=null;
		int eid=scanner.nextInt();
		try {
			
			employee=dao.viewEmployee(eid);
			if(employee.getEmpId()!=0)
				System.out.println(employee);
			else
				System.out.println("Employee not found");
		} catch (NotFoundException e) {
			e.getMessage();
		}
	}
	
	public static void add(){
		System.out.println("Enter employee id ");
		int eid=scanner.nextInt();
		System.out.println("Employee name: ");
		String ename=scanner.next();
		System.out.println("salary");
		double salary=scanner.nextDouble();
		System.out.println("department id");
		int did=scanner.nextInt();
		System.out.println("date");
		String strdate=scanner.next();
		System.out.println("Employee password: ");
		String pwd=scanner.next();

		DateTimeFormatter dateTimeFormatter=DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate doj =LocalDate.parse(strdate,dateTimeFormatter);
		
		Employee employee= new Employee(eid, ename, salary, did, doj,pwd,eid+".jpg");
		int result=0;
		try {
			result=dao.addEmployee(employee);
			if(result>0)
			System.out.println("Employee added");
			else 
				System.out.println("Employee not added");
		} catch ( IdException e) {
			System.out.println("Invaild ID");
		}
		
	}

}
