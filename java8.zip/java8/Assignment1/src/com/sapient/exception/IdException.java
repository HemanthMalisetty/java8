package com.sapient.exception;

public class IdException extends Exception{

	public IdException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public IdException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
