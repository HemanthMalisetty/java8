package com.sapient.services;

public interface Atm {
	void withdraw();
	void deposite();
	void getBalance();
}
