package com.sapient.services;

public interface Agent {
	
	public abstract void clearPd();
	void approveLoan();
	
}
