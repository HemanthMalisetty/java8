package com.apient.lambda;

@FunctionalInterface    //optional when one abstract method
public interface ICalculator {
	int doCal(int a,int b);
//	int doSum(int a,int b);
}
