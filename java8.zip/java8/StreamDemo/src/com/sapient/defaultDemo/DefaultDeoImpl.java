package com.sapient.defaultDemo;

public class DefaultDeoImpl implements DefaultDao {

	@Override
	public void m1() {
		System.out.println("impl1-->m1");

	}

	

	@Override
	public void m2() {
		System.out.println("impl1-->m2");

	}

}
