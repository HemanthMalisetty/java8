package com.sapient.fp;

@FunctionalInterface
public interface ICase {
	String changeCase(String str);
}
